<?php
/**
* Here is the serverless function entry
* for deployment with Vercel.
*/
require __DIR__.'/../public/index.php';