import { Link } from '@inertiajs/react'
import React from 'react'

const Mt = () => {
  return (
    <div className='flex justify-center items-center'>
        <h1 className='text-6xl'>Under Maintenance</h1>
    </div>
  )
}

export default Mt